﻿namespace bar
{
    partial class Help
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxtHelp = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // rchTxtHelp
            // 
            this.rchTxtHelp.Location = new System.Drawing.Point(34, 30);
            this.rchTxtHelp.Name = "rchTxtHelp";
            this.rchTxtHelp.ReadOnly = true;
            this.rchTxtHelp.Size = new System.Drawing.Size(260, 276);
            this.rchTxtHelp.TabIndex = 0;
            this.rchTxtHelp.TabStop = false;
            this.rchTxtHelp.Text = "";
            // 
            // Help
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(337, 348);
            this.Controls.Add(this.rchTxtHelp);
            this.Name = "Help";
            this.Text = "Help";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxtHelp;
    }
}